package com.portfolio.afm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AfmApplicationTests {

	@Test
	void contextLoads() {
	}

}
